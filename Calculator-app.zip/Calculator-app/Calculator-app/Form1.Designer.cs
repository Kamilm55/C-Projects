﻿namespace Calculator_app
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            richTextBox1 = new RichTextBox();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ControlLightLight;
            button1.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(28, 174);
            button1.Name = "button1";
            button1.Size = new Size(65, 65);
            button1.TabIndex = 0;
            button1.Text = "7";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(29, 32);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(293, 51);
            richTextBox1.TabIndex = 2;
            richTextBox1.Text = "";
            richTextBox1.TextChanged += richTextBox1_TextChanged;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ControlLightLight;
            button2.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button2.Location = new Point(106, 174);
            button2.Name = "button2";
            button2.Size = new Size(65, 65);
            button2.TabIndex = 3;
            button2.Text = "8";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ControlLightLight;
            button3.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button3.Location = new Point(28, 316);
            button3.Name = "button3";
            button3.Size = new Size(65, 65);
            button3.TabIndex = 4;
            button3.Text = "1";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.ControlLightLight;
            button4.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button4.Location = new Point(28, 245);
            button4.Name = "button4";
            button4.Size = new Size(65, 65);
            button4.TabIndex = 5;
            button4.Text = "4";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.BackColor = SystemColors.ControlLightLight;
            button5.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button5.Location = new Point(256, 174);
            button5.Name = "button5";
            button5.Size = new Size(65, 65);
            button5.TabIndex = 6;
            button5.Text = "+";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.BackColor = SystemColors.ControlLightLight;
            button6.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button6.Location = new Point(181, 174);
            button6.Name = "button6";
            button6.Size = new Size(65, 65);
            button6.TabIndex = 7;
            button6.Text = "9";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.BackColor = SystemColors.ControlLightLight;
            button7.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button7.Location = new Point(106, 245);
            button7.Name = "button7";
            button7.Size = new Size(65, 65);
            button7.TabIndex = 8;
            button7.Text = "5";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.BackColor = SystemColors.ControlLightLight;
            button8.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button8.Location = new Point(106, 387);
            button8.Name = "button8";
            button8.Size = new Size(65, 65);
            button8.TabIndex = 9;
            button8.Text = ".";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.BackColor = SystemColors.ControlLightLight;
            button9.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button9.Location = new Point(28, 387);
            button9.Name = "button9";
            button9.Size = new Size(65, 65);
            button9.TabIndex = 10;
            button9.Text = "0";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.BackColor = SystemColors.ControlLightLight;
            button10.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button10.Location = new Point(181, 245);
            button10.Name = "button10";
            button10.Size = new Size(65, 65);
            button10.TabIndex = 11;
            button10.Text = "6";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click;
            // 
            // button11
            // 
            button11.BackColor = SystemColors.ControlLightLight;
            button11.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button11.Location = new Point(181, 316);
            button11.Name = "button11";
            button11.Size = new Size(65, 65);
            button11.TabIndex = 12;
            button11.Text = "3";
            button11.UseVisualStyleBackColor = false;
            button11.Click += button11_Click;
            // 
            // button12
            // 
            button12.BackColor = SystemColors.ControlLightLight;
            button12.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button12.Location = new Point(181, 387);
            button12.Name = "button12";
            button12.Size = new Size(65, 65);
            button12.TabIndex = 13;
            button12.Text = "=";
            button12.UseVisualStyleBackColor = false;
            button12.Click += button12_Click;
            // 
            // button13
            // 
            button13.BackColor = SystemColors.ControlLightLight;
            button13.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button13.Location = new Point(106, 316);
            button13.Name = "button13";
            button13.Size = new Size(65, 65);
            button13.TabIndex = 14;
            button13.Text = "2";
            button13.UseVisualStyleBackColor = false;
            button13.Click += button13_Click;
            // 
            // button14
            // 
            button14.BackColor = SystemColors.ControlLightLight;
            button14.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button14.Location = new Point(256, 387);
            button14.Name = "button14";
            button14.Size = new Size(65, 65);
            button14.TabIndex = 15;
            button14.Text = "/";
            button14.UseVisualStyleBackColor = false;
            button14.Click += button14_Click;
            // 
            // button15
            // 
            button15.BackColor = SystemColors.ControlLightLight;
            button15.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button15.Location = new Point(256, 316);
            button15.Name = "button15";
            button15.Size = new Size(65, 65);
            button15.TabIndex = 16;
            button15.Text = "x";
            button15.UseVisualStyleBackColor = false;
            button15.Click += button15_Click;
            // 
            // button16
            // 
            button16.BackColor = SystemColors.ControlLightLight;
            button16.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button16.Location = new Point(256, 245);
            button16.Name = "button16";
            button16.Size = new Size(65, 65);
            button16.TabIndex = 17;
            button16.Text = "-";
            button16.UseVisualStyleBackColor = false;
            button16.Click += button16_Click;
            // 
            // button17
            // 
            button17.BackColor = SystemColors.ControlLightLight;
            button17.Font = new Font("SansSerif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button17.Location = new Point(28, 103);
            button17.Name = "button17";
            button17.Size = new Size(65, 65);
            button17.TabIndex = 18;
            button17.Text = "C";
            button17.UseVisualStyleBackColor = false;
            button17.Click += button17_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(352, 475);
            Controls.Add(button17);
            Controls.Add(button16);
            Controls.Add(button15);
            Controls.Add(button14);
            Controls.Add(button13);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(richTextBox1);
            Controls.Add(button1);
            Name = "Form1";
            Padding = new Padding(5);
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private RichTextBox richTextBox1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
    }
}